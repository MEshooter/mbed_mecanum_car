#include "CmdLine.h"
#include <sstream>
#include <string>

CmdLine::CmdLine(): serialPort(USBTX, USBRX) {
    start();
}

void CmdLine::readCmd() {
    char ch;
    while(serialPort.readable()) {
        serialPort.read(&ch, 1);
        switch(ch){
            case 8:
            case 127:
                serialPort.write("\b \b ", 3);
                rxBuffer.pop_back();
                break;
            case '\n':
            case '\r':
                processCmd();
                cout << "> ";
                fflush(stdout);
                break;
            default:
                serialPort.write(&ch, 1);
                rxBuffer += ch;
                break;
        }
    }
}

void CmdLine::start() {
    cmdThread.start(callback(&cmdEventQueue, &EventQueue::dispatch_forever));
    serialPort.sigio(callback([&]() {
        cmdEventQueue.call(callback(this, &CmdLine::readCmd));
    }));
    cout << "\nCommand line started.\n";
    cout << "> ";
    fflush(stdout);
}

void CmdLine::processCmd() {
    cout << "\nReceived command: \'" << rxBuffer << "\'\n";
    istringstream iss(rxBuffer);
    string cmdType;
    iss >> cmdType;
    if(cmdType == "LED") {
        string stat;
        if(iss >> stat) {
            if(stat == "on") {
                led = 1;
            }
            else if(stat == "off") {
                led = 0;
            }
            else {
                cout << "Invalid format.\n";
            }
        }
        else {
            cout << "Parameter missing.\n";
        }
    }
    else if(cmdType == "motor") {
        string cmdName;
        if(iss >> cmdName){
            if(cmdName == "speed") {
                int speed;
                iss >> speed;
                motor1.setSpeed(speed);
                cout << "Motor Period: " << to_string(motor1.getPeriod()) << "\n";
                cout << "Successfully set speed as " << std::to_string(motor1.getSpeed()) << "% .\n";
            }
            else if(cmdName == "dir") {
                int dir;
                iss >> dir;
                motor1.setDirection(dir);
                cout << "Successfully set direction.\n";
            }
        }
        else {
            cout << "Parameter missing.\n";
        }
    }
    else {
        cout << "No such command.\n";
    }
    rxBuffer.clear();
}
