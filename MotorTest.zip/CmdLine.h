#ifndef __CMDLINE_H
#define __CMDLINE_H

#include "mbed.h"
#include "Motor.h"
#include <string>
#include <iostream>
#include <sstream>

extern DigitalOut led;
extern Motor motor1;
class CmdLine {
private:
    string rxBuffer;
    size_t rxIndex = 0;
    BufferedSerial serialPort;
    Thread cmdThread;
    EventQueue cmdEventQueue;
public:
    CmdLine();
    void start();
    void readCmd();
    void processCmd();
};

#endif
