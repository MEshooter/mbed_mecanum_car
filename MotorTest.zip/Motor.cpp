#include "Motor.h"

Motor::Motor(PinName _m, PinName _l1, PinName _l2, int _p): 
    pwmSignal(_m), logicCon1(_l1), logicCon2(_l2), pwmPeriod(_p) {
    start();
}

void Motor::start(){
    setDirection(1);
    setSpeed(0);
    pwmSignal.period_us(pwmPeriod);
}

void Motor::setSpeed(int speedPercent){
    int width = speedPercent / 100.0 * pwmPeriod;
    pwmSignal.pulsewidth_us(width);
}

void Motor::setDirection(int dir){
    if(dir > 0){
        logicCon1 = 1;
        logicCon2 = 0;
    }
    else if(dir < 0){
        logicCon1 = 0;
        logicCon2 = 1;
    }
    else{
        logicCon1 = logicCon2 = 0;
    }
}

int Motor::getPeriod(){
    return pwmPeriod;
}

int Motor::getSpeed(){
    return 1.0 * pwmSignal.read_pulsewidth_us() / pwmSignal.read_period_us() * 100;
}
