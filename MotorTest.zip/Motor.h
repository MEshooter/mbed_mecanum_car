#ifndef __MOTOR_H
#define __MOTOR_H

#include "mbed.h"

class Motor{
    PwmOut pwmSignal;
    DigitalOut logicCon1, logicCon2;
    int pwmPeriod;
public:
    Motor(PinName, PinName, PinName, int);
    void start();
    void setSpeed(int);
    void setDirection(int);
    int getPeriod();
    int getSpeed();
    int getDirection();
};

#endif