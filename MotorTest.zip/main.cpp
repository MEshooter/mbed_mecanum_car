#include "mbed.h"
#include "CmdLine.h"
#include "Motor.h"

CmdLine cmd_PC;
DigitalOut led(LED1);
Motor motor1(PA_0, PC_1, PC_0, 1000);
// change the pin according to neeeds

int main()
{
    while (true) {

    }
}

